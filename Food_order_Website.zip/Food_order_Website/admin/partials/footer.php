<!--  Footer Section Start -->
<div class="footer">
        <div class="wrapper">
            <p class="text-center">2023 All rights reserved, Some Restaurant. Developed By -- <a href="https://www.linkedin.com/in/mannu-kumar-87a9a4257/">Mannu Kumar </a></p>
            </div>
        </div>
        <!--  footer Section Ends -->
    </body>


</html>
